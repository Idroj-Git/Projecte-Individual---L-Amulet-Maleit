using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void StartGame()
    {
        if (RuntimeGameSettings.Instance.GetLastScene() == SceneController.GetMainMenuIndex())
        {
            SceneController.LoadMainWorldScene();
        }
        else
        {
            SceneController.LoadSceneByIndex(RuntimeGameSettings.Instance.GetLastScene());
        }
    }

    public void ExitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
