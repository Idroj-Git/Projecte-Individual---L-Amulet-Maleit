Brown Rock Tileset - Version 2
by kodzegura from Mushra Games

Features:

- Brown Rock Area: various tiles, pillars, bridges, and stairs.
- Green Area: grass tiles, trees, and bushes.
- Additional rural environment including 3 houses.
- Red Rock Area: available on Patreon and Ko-fi for free (link below)
- Roads & Rock Textures
- Animated water tiles
- (Coming soon) Animated grass tiles
- (Planned) Animations: Hero, Foes, NPСs

Find more free assets on our Patreon/Kofi pages (donation isn't required, but highly appreciated):
https://www.patreon.com/MushraGames
https://ko-fi.com/mushragames

Need custom art or music for your project? Contact us!

Email: mushragames@gmail.com.
Twitter/X: @mushra_games
Instagram: @mushragames
GameJolt: @mushragames
Tumblr: @mushra-games

Also, tell about your game in the comments/DMs, we'd be happy to play it!
Thanks for downloading our assets, best of luck with your project!
